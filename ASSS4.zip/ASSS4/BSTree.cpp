/*
 * BSTree.cpp
 *
 *  Created on: Mar 5, 2010
 *      Author: mori
 */
#include <iostream>
#include "BSTree.h"


BSTree::BSTree() {
	root = NULL;
}


BSTree::~BSTree() {

	Destroy_tree(root);
}

void BSTree::Destroy_tree(Node* leaf)
{
	if(leaf != NULL)
	{
		Destroy_tree(leaf->get_left());
		Destroy_tree(leaf->get_right());
		delete leaf;
	}
}


bool BSTree::insert(string x, char y, int z) {
	Customer* new_customer = new Customer(x,y,z);

	if(root == NULL)			//empty tree
	{
		root = new Node();
		root->set_customer(new_customer);
		root->set_left(NULL);
		root->set_right(NULL);
		return true;
	}

	else
	{
		Tree_insert(new_customer,root);
		return true;

	}


	return false;
}

void BSTree::Tree_insert(Customer* new_customer,Node* leaf)
{
	if(new_customer < leaf->get_customer())			//our key is smaller so we insert in the left subtree
	{
		if(leaf->get_left() != NULL)
		{
			Tree_insert(new_customer , leaf->get_left());
		}

		else
		{
			leaf->set_left(new Node () );
			leaf->get_left()->set_customer(new_customer);
			leaf->get_left()->set_left(NULL);
			leaf->get_left()->set_right(NULL);
		}
	}

	else if (leaf->get_customer() <= new_customer)
	{
		if(leaf->get_right() != NULL)
		{
			Tree_insert(new_customer, leaf->get_right());
		}

		else
		{
			leaf->set_right(new Node() );
			leaf->get_right()->set_customer(new_customer);
			leaf->get_right()->set_right(NULL);
			leaf->get_right()->set_left(NULL);

		}
	}
}


bool BSTree::remove(string x, char y) {
	return false;
}


bool BSTree::search(string x, char y) {
	Customer* new_customer = new Customer(x,y,0);

	if(BinarySearch(new_customer , root))
	{
		return true;
	}

	return false;
}

bool BSTree::BinarySearch(Customer* key, Node* leaf)
{

	if(leaf->get_customer() == key)
	{
		return true; // target found
	}

	else
	{
		if(leaf->get_customer() > key)
		{
			return BinarySearch(key, leaf->get_left() );
		}

		if(leaf->get_customer() < key)
		{
			return BinarySearch(key, leaf->get_right());
		}
	}

	return false;

}


vector<Customer> BSTree::rangeSearch(string x, char y, string z, char a) {
}


void BSTree::inOrderPrint() {

	InorderPrintHelper(root);


}

void BSTree::InorderPrintHelper(Node* starting_node)
{
	if(starting_node != NULL)
	{
		if(starting_node->get_left())
		{
			InorderPrintHelper(starting_node->get_left());
		}

		cout << starting_node->get_customer() << endl;


		if(starting_node->get_right())
		{
			InorderPrintHelper(starting_node->get_right());

		}
	}
}

/*
 * Node.h
 *
 *  Created on: Mar 5, 2010
 *      Author: mori
 */

#ifndef NODE_H_
#define NODE_H_

#include "Customer.h"

class Node {
public:

  Node();
  Node(Customer* new_customer, Node*new_left , Node*new_right);
  ~Node();
  void set_left(Node* new_left);
  void set_right(Node* new_right);
  void set_customer(Customer* cust);
  Node* get_left();
  Node* get_right();
  Customer* get_customer();
private:
  Customer* customer;
  Node* left_child;
  Node* right_child;
};

#endif /* NODE_H_ */
